/*
 * File:   main.c
 * Author: celom
 *
 *
 * 
 * Created on 28 de Agosto de 2025, 11:46
 */


#include "configbits.h"
#define _XTAL_FREQ 8000000
#include <xc.h>
#include <stdint.h>        /* For uint8_t definition */
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include "adc.h"
#include "flexlcd.h"
#include "itoa.h"
#include "debounce.h"
#include "pwm.h"

#define bt_manual_heater 0 
#define bt_switch_mode 1 

// Filters
int filter_bt_on_off = t_filter; // filtro - ligar e desligar o aquecedor.
int filter_bt_mode = t_filter; // filtro - alterar o modo de operacao.

// Flags
int bt_op_on_off = 0; // botao de ligar e desligar o aquecedor.
int bt_op_mode = 0; // botao para alterar entre modos de operacao.



//Variables
unsigned int adcResult; //temperatur do sensor 
unsigned int pot_value;
char tecla, key;
float temp = 0; // Temperatura.
char str[4], date[10], time[10];
int count = 0; //Contador do timer.

bool automatico = 0;
bool First = 1;  

int lastADC = 0;
int counter_adc = 0;

int OPERATION_MODE = 0; // Comeca em MANUAL.

//Liga e desliga aquecedor
void aquecedor_on_off(){
    //LATBbits.LB7 = 1;
    TougleBit(&LATC, 5);
}

//Trocar modos de opera��o (manual/automatico).
void change_mode(){
    OPERATION_MODE = !OPERATION_MODE;
    First = 1;
}

//Fun��o Principal
void main(void) {
    __delaywdt_ms(1000);
     //ADCON0 = 0b00000000;
    ADCON1 = 0x6; //configura todos os pinos AD da porta B como I/O
    //ADCON2 = 0b00000000;
    //INTCON = 0b00000000;
    //INTCON2 = 0b00000000;
    INTCON2bits.RBPU = 0; // Pull-up resistors off
        
    // Input or Output
    TRISA = 0xFF;
    TRISB = 0b00000011; 
    TRISC = 0b00000000;
    TRISD = 0b00001111; 
    TRISE = 0b00000000;
    // Clear ports
    PORTA = 0; 
    LATA = 0;
    PORTB = 0; 
    LATB = 0;
    PORTC = 0; 
    LATC = 0b00000000; //aquecedor
    PORTD = 0; 
    LATD = 0;
    PORTE = 0; 
    LATE = 0;
    
    //-----------------------------------------------------------------
    //Configuracoes do TIMER0. Contador 1 segundo.
    INTCONbits.TMR0IF = 0; // Flag - TMR0 register has overflowed.
    INTCONbits.TMR0IE = 1; // Enable - TIMER0.
    T0CON = 0b11000101; // 8bit and 1:64 Prescale
    TMR0 = 131;
    //-----------------------------------------------------------------
    ei();
    
    adc_init(); // configura registradores ADCON
    Lcd_Init();
    Lcd_Cmd(LCD_CURSOR_OFF); 
    
    PWM1_Init(1000);  // configura frequencia do PWM para 1kHz
    PWM1_Start(); // configura registradores e inicia PWM
    PWM1_Set_Duty(0);
    
    // ventilador est� em RC2
    // lm35 em AN0
    int counter = 0;
   
    sprintf(str, "Duty C: 000%%"); // 05.f = 5 d�gitos (preencher
    Lcd_Out(3, -4, str);
    
    while(1){
        CLRWDT();
        
        Debounce(PORTB, bt_switch_mode, &bt_op_mode, &filter_bt_mode, change_mode);
        //Lcd_Out(2, 0, "TESTE    ");
        
        switch (OPERATION_MODE)
        {
            case 0://MANUAL.
                if (First){
                    //Lcd_Cmd(LCD_CURSOR_OFF);
                    Lcd_Out(1, 0, "MODO MANUAL     ");
                    Lcd_Out(2, 0, "                ");
                    First = 0;
                }
                Debounce(PORTB, bt_manual_heater, &bt_op_on_off, &filter_bt_on_off, aquecedor_on_off);
            break;

           case 1://AUTOMATICO.
                adcResult = (adc_amostra(1));  //Sensor de temperatura.
                temp = (adcResult*500.0)/1023;
//                sprintf(str, "Temp = %05.2f C", temp); // 05.f = 5 d�gitos (preencher
//                Lcd_Out(2, 0, str);
                
                if(First && OPERATION_MODE){
                    if (temp < 40.0 && PORTCbits.RC5 == 0){
                        aquecedor_on_off();
                    }
                    Lcd_Out(1, 0, "MODO AUTOMATICO");
                    //Lcd_Out(2, 0, "                ");
                    First = 0;
                    TMR0 = 131;
                    count = 0;
                    automatico = 1;                  
                }
                if (temp > 40.0){
                    OPERATION_MODE = 0;
                    automatico = 0;
                    First = 1;
                    aquecedor_on_off();
                } 
          
            break;
        }
        counter_adc++;
        if(counter_adc > 100){
            adcResult = (adc_amostra(0));  //Potenciometro.
        }
        //sprintf(str, "ADC = %05d C", adcResult/4); // 05.f = 5 d�gitos (preencher
        //Lcd_Out(2, 0, str);
        if(adcResult != lastADC){
            PWM1_Set_Duty((adcResult)/4);
            int duty = ((adcResult)/4)/2.55;
            sprintf(str, "Duty C: %03d%%", duty); // 05.f = 5 d�gitos (preencher
            Lcd_Out(3, -4, str);
            lastADC = adcResult;
        }
        
        
        
    }
    return;
}

//Fun��o contador de segundos
void interrupt isr(void){
    if (INTCONbits.TMR0IF == 1)
    {
        INTCONbits.TMR0IF = 0; // Clear interrupt flag
        TMR0 = 131;
        count ++;
        //Lcd_Out(4, -4, str);
        if (count == 2500 && automatico) //5 segundo.
        {
            count = 0;
            OPERATION_MODE = 0;
            LATBbits.LATB5 = ~LATBbits.LATB5; //pisca led
            automatico = 0;
            First = 1;
            aquecedor_on_off();
        }     
    }
}