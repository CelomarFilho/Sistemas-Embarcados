
#define t_filter 10;

void SetBit(unsigned *port, unsigned pin);

void ClearBit(unsigned *port, unsigned pin);

void TougleBit(unsigned *port, unsigned pin);

int CheckBit(unsigned port, unsigned pin);

void Debounce(unsigned port, unsigned pin, unsigned *bt_press, unsigned *filter, void (*ptr_f)(void));